const express = require('express')

const app = express()

app.use(express.urlencoded())
app.use(express.json())

app.use(express.static('client'))
app.use('/', express.static('client'))

app.listen(1010, function() {
    console.log('listening on port 1010')
})