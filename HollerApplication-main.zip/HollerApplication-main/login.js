document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var usernameInput = document.getElementById("username").value;
    var passwordInput = document.getElementById("password").value;

    if (usernameInput === "user" && passwordInput === "pass") {
        document.getElementById("loginStatus").textContent = "Login successful!";
        // Redirect to a different page after successful login
        // You can add this line to redirect:
        // window.location.href = "dashboard.html";
    } else {
        document.getElementById("loginStatus").textContent = "Invalid username or password.";
    }
});